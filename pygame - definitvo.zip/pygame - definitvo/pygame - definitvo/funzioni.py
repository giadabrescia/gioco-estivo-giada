import pygame, sys
from random import randint

WINDOW_SIZE = (640, 480)

class puffo:
    def __init__(self, pos, size, screen) -> None:
        self.pos = pos
        self.size = size
        self.image = pygame.image.load("immagini\Puffo.png")
        self.image = pygame.transform.scale(self.image, self.size)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = self.pos
        self.vel = [3, 3]
        self.muovi_dx = False
        self.muovi_sx = False
        self.muovi_giu = False
        self.screen = screen
        self.salto = False
    
    def move_giu(self):
        self.muovi_giu = True

    def move_su(self):
        self.muovi_su = True

    def stop_su(self):
        self.muovi_su = False
    def stop_giu(self):
        self.muovi_giu= False

    def fermo(self, bole):
            if bole:
                self.vel = [0, 0]
            else: self.vel = [2, 2]

    def muovi(self):
        
        if self.muovi_giu:
            if not self.rect.top >= WINDOW_SIZE[1]-self.size[1]:
                self.rect.top += self.vel[1]
        if self.muovi_su:
            if not self.rect.top <=0:
                self.rect.top -= self.vel[1]
   
    def draw(self):
        self.image= pygame.image.load('immagini\Puffo.png')
        self.image = pygame.transform.scale(self.image, self.size)
        self.screen.blit(self.image, self.rect)
    
    def setPos(self,pos):
        self.pos = pos
        self.rect.x, self.rect.y = self.pos
