import pygame
import sys
from funzioni import puffo
from pygame.locals import *
from random import randint
from pygame.color import THECOLORS as COLORS
pygame.init()

BLUE = (0, 110, 200)
FPS = 120

WINDOW_SIZE = (640, 480)
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption('gioco')
screen.fill((0, 110, 200))


TIMERSHOT = pygame.event.custom_type()
pygame.time.set_timer(TIMERSHOT, 500)
incremento_al_sec = 1
sfondo = pygame.image.load("immagini\Sfondo.png")
sfondo = pygame.transform.scale(sfondo, WINDOW_SIZE)

puffo = puffo([0, WINDOW_SIZE[1]-50], (130, 70), screen)


en_i1 = pygame.image.load('immagini\Palla.png')
en_i1 = pygame.transform.scale(en_i1, (45, 45))
en_r1 = en_i1.get_rect()
en_r1.x, en_r1.y = (randint(800, 1000), randint(10, 450))


en_i2 = pygame.image.load('immagini\Palla.png')
en_i2 = pygame.transform.scale(en_i2, (45, 45))
en_r2 = en_i2.get_rect()
en_r2.x, en_r2.y = (randint(800, 1000), randint(10, 450))

en_i3 = pygame.image.load('immagini\Palla.png')
en_i3 = pygame.transform.scale(en_i3, (45, 45))
en_r3 = en_i3.get_rect()
en_r2.x, en_r2.y = (randint(800, 1000), randint(10, 450))

garga_i = pygame.image.load('immagini\Garga.png')
garga = pygame.transform.scale(garga_i, (400, 500))
garga_r = garga.get_rect()
garga_r.x, garga_r.y = (WINDOW_SIZE[0]-200, 40)


clock = pygame.time.Clock()
font = pygame.font.Font('fonts\Letterland.otf', 25)
biggerFont = pygame.font.Font('fonts\Letterland.otf', 50)


def menu():

    while True:
        clock.tick(FPS)
        screen.blit(sfondo, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                click = True
            else:
                click = False

        mousePos = pygame.mouse.get_pos()

        btnSurface = biggerFont.render("Gioca", True, COLORS['red'])
        btnSize = btnSurface.get_size()
        btnRect = btnSurface.get_rect()
        btnRect.x, btnRect.y = (
            WINDOW_SIZE[0]/2) - (btnSize[0]/2), (WINDOW_SIZE[1]/2) - (btnSize[1]/2)

        color = (255, 255, 255)
        if mousePos[0] >= btnRect.x and mousePos[1] >= btnRect.y and mousePos[0] <= btnRect.x + btnSize[0] and mousePos[1] <= btnRect.y + btnSize[1]:
            
            color = (255, 0, 0)
            if click == True:
                gameLoop()
                return
        click = False

        screen.blit(btnSurface, btnRect)

        pygame.display.update()


def gameOver():
    screen.fill((0, 0, 0))  
    
    gameOverText = font.render("Game Over!", True, BLUE)
    gameOverRect = gameOverText.get_rect()
    gameOverRect.x, gameOverRect.y = (
        WINDOW_SIZE[0]/2-gameOverRect.width/2, WINDOW_SIZE[1]/2 - gameOverRect.height)

    retrySurf = font.render("Torna al menu", True, BLUE)
    retryRect = retrySurf.get_rect()
    retrySize = retrySurf.get_size()
    retryRect.x, retryRect.y = (
        WINDOW_SIZE[0]/2) - (retrySize[0]/2), gameOverRect.y + gameOverRect.height + (retrySize[1]/2)
 
    screen.blit(gameOverText, gameOverRect)
    screen.blit(retrySurf, retryRect)
    pygame.display.update()
    while True:
        clock.tick(FPS)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                click = True
            else:
                click = False

        mousePos = pygame.mouse.get_pos()
        color = (255, 255, 255)
        if mousePos[0] >= retryRect.x and mousePos[1] >= retryRect.y and mousePos[0] <= retryRect.x + retrySize[0] and mousePos[1] <= retryRect.y + retrySize[1]:

            color = (0, 255, 0)
            if click == True:
                menu()
                return

        pygame.display.update()


pass


def gameLoop():
    tempo = 0
    vite = 5
    score = 0
    vel_en = 4
    n = 1
    puffo.setPos([0, WINDOW_SIZE[1]-50])
    while True:
        if score <= 0:
            score = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == TIMERSHOT:
                score += incremento_al_sec

        keys = pygame.key.get_pressed()

        if keys[K_SPACE] and not keys[K_w] and not keys[K_s] and not keys[K_a] and not keys[K_d]:
            puffo.fermo(True)
            attacco = True

        en_r1.x -= vel_en
        if en_r1.x < 0:
            score += 2
            en_r1.x = randint(700, 1100)
            en_r1.y = randint(10, 450)

        en_r2.x -= vel_en
        if en_r2.x < 0:
            score += 2
            en_r2.x = randint(700, 1100)
            en_r2.y = randint(10, 450)

        en_r3.x -= vel_en
        if en_r3.x < 0:
            score += 2
            en_r3.x = randint(700, 1100)
            en_r3.y = randint(10, 450)

        if keys[K_w]:
            puffo.move_su()
            puffo.fermo(False)
        else:

            puffo.stop_su()
            puffo.fermo(False)
        if keys[K_s]:
            puffo.move_giu()
            puffo.fermo(False)
        else:
            puffo.stop_giu()
            puffo.fermo(False)

        if puffo.rect.colliderect(en_r1):
            vite -= 1
            score -= 5
            en_r1.x = randint(500, 700)
            en_r1.y = randint(100, 250)

        if puffo.rect.colliderect(en_r2):
            vite -= 1
            score -= 5
            en_r2.x = randint(500, 700)
            en_r2.y = randint(100, 250)

        if puffo.rect.colliderect(en_r3):
            vite -= 1
            score -= 5
            en_r3.x = randint(500, 700)
            en_r3.y = randint(100, 250)

        if vite == 5:
            vite_i = pygame.image.load("immagini\Vite-5-5.png")
            vite_i = pygame.transform.scale(vite_i, (100, 20))
        if vite == 4:
            vite_i = pygame.image.load("immagini\Vite-4-5.png")
            vite_i = pygame.transform.scale(vite_i, (100, 20))
        if vite == 3:
            vite_i = pygame.image.load("immagini\Vite-3-5.png")
            vite_i = pygame.transform.scale(vite_i, (100, 20))
        if vite == 2:
            vite_i = pygame.image.load("immagini\Vite-2-5.png")
            vite_i = pygame.transform.scale(vite_i, (100, 20))
        if vite == 1:
            vite_i = pygame.image.load("immagini\Vite-1-5.png")
            vite_i = pygame.transform.scale(vite_i, (100, 20))
        if vite <= 0:
            # game over screen
            gameOver()
            return
            vite = 5
            score = 0

        else:
            screen.fill((0, 110, 200))

        screen.blit(sfondo, (0, 0))
        screen.blit(en_i3, en_r3)
        screen.blit(en_i2, en_r2)
        screen.blit(en_i1, en_r1)
        screen.blit(garga_i, garga_r)

        screen.blit(vite_i, (10, 10))
        puffo.muovi()

        puffo.draw()

        score_text = font.render(f'Score: {score}', True, (255, 255, 255))
        screen.blit(score_text, (400, 10))

        pygame.display.update()
        clock.tick(FPS)
menu()
